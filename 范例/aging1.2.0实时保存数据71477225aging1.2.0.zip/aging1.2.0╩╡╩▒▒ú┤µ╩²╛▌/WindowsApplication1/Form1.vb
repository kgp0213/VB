﻿Imports Microsoft.Office.Interop
Imports System.IO                     '存储文件
Imports System.Windows.Forms.DataVisualization.Charting

Public Class Form1
    Private objCa200 As CA200SRVRLib.Ca200
    Private WithEvents objCa As CA200SRVRLib.Ca
    Private objProbe As CA200SRVRLib.Probe
    Private isMsr As Boolean
    Private Declare Function timeGetTime Lib "winmm.dll" () As Long      '****延时函数,单位是毫秒,支持小数****

    Public Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        On Error GoTo er
        objCa200 = New CA200SRVRLib.Ca200
        objCa200.AutoConnect()
        objCa = objCa200.SingleCa
        objProbe = objCa.SingleProbe

        Chart1.ChartAreas.Clear() '清除所有绘图区
        Dim newChartAreas1 As New ChartArea("Default") '新增绘图区
        Chart1.ChartAreas.Add(newChartAreas1)
        Chart1.ChartAreas("Default").BackColor = Color.FromName("GradientInactiveCaption") '设置绘图区颜色
        Chart1.ChartAreas("Default").BackGradientStyle = GradientStyle.HorizontalCenter '设置绘图区颜色渐变方式
        Chart1.ChartAreas("Default").AxisX.IsMarginVisible = True
        'Chart1.ChartAreas("Default").Area3DStyle.Enable3D = True '启用3D显示
        Chart1.ChartAreas("Default").AxisX.Title = "时间" 'X轴名称
        Chart1.ChartAreas("Default").AxisY.Title = "亮度百分比" 'Y轴名称
        Chart1.ChartAreas("Default").AxisY.Minimum = 0.94
        Chart1.ChartAreas("Default").AxisY.Maximum = 1.01
        Chart1.ChartAreas("Default").AxisY.Interval = 0.01

        Chart1.Titles.Clear()
        Dim newTitles1 As New Title("aging亮度衰减图") '建立标题
        newTitles1.Text = "aging亮度衰减图"
        Chart1.Titles.Add(newTitles1)

        Chart1.Series.Clear() '清除所有数据集
        Dim newSeries1 As New Series("初始值") '新增数据集
        newSeries1.ChartType = SeriesChartType.Line '直线
        newSeries1.BorderWidth = 1
        newSeries1.Color = Color.Blue
        newSeries1.XValueType = ChartValueType.Time
        newSeries1.IsValueShownAsLabel = False
        Chart1.Series.Add(newSeries1)

        Dim newSeries2 As New Series("当前值")
        newSeries2.ChartType = SeriesChartType.Line
        newSeries2.BorderWidth = 2
        newSeries2.Color = Color.Green
        newSeries2.XValueType = ChartValueType.Time
        newSeries2.IsValueShownAsLabel = False
        newSeries2.MarkerStyle = MarkerStyle.Square
        Chart1.Series.Add(newSeries2)

        Dim newSeries3 As New Series("LT95")
        newSeries3.ChartType = SeriesChartType.Line
        newSeries3.BorderWidth = 1
        newSeries3.Color = Color.OrangeRed
        newSeries3.XValueType = ChartValueType.Time
        newSeries3.IsValueShownAsLabel = False
        Chart1.Series.Add(newSeries3)

        Exit Sub
er:
        DspError()
        End
    End Sub
    Public Sub ButtonCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonCancel.Click
        isMsr = False
        ButtonCancel.Enabled = False
        ButtonMeasure.Enabled = True
        ButtonCalZero.Enabled = True
    End Sub
    Public Sub ButtonMeasure_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonMeasure.Click
        Dim i As Integer
        Dim t1
        Dim a, k
        Dim Period As Double = 1000 * 60 * Val(TextBox2.Text)

        a = Me.DataGridView1.RowCount
        t1 = timeGetTime
        Dim current_time
        current_time = DateTime.Now.ToString("dd HH:mm")
        objCa.Measure()
        k = objProbe.Lv

        On Error GoTo er
        isMsr = True
        ButtonCancel.Enabled = True    '让其他的按钮不可使用
        ButtonMeasure.Enabled = False
        ButtonCalZero.Enabled = False
        Button2.Enabled = False
        '##########################################excel自动保存程序###########################
        Dim xlApp As Excel.Application
        Dim xlBook As Excel.Workbook
        Dim xlSheet1 As Excel.Worksheet
        xlApp = CreateObject("Excel.Application")
        xlBook = xlApp.Workbooks.Add
        xlSheet1 = xlBook.Worksheets("sheet1")
        xlSheet1.Name = "aging001"
        xlApp.Visible = False
        Dim m As Integer
        For m = 0 To DataGridView1.ColumnCount - 1
            xlSheet1.Cells(1, m + 1) = Me.DataGridView1.Columns(m).HeaderText
        Next m
        If Dir("D:\寿命测试", vbNormal Or vbReadOnly Or vbSystem Or vbHidden Or vbDirectory) <> "" Then
            Debug.Print("存在")
        Else
            MkDir("D:\寿命测试")
        End If
        filename = DateTime.Now.ToString("yyMMddHHmm")
        xlBook.SaveAs("D:\寿命测试\" & filename & ".xls")
        '保存
        '关闭
        xlApp.DisplayAlerts = False
        xlBook.Close()
        xlApp.Quit()
        xlApp = Nothing
        xlBook = Nothing
        xlSheet1 = Nothing
        '##########################################excel自动保存程序###########################
        For i = a To Val(TextBox1.Text) - 1
            '##########################################excel自动保存程序###########################
            Dim ex As Object
            ex = CreateObject("Excel.Application")
            ex.Visible = False
            ex.Workbooks.Open("D:\寿命测试\" & filename & ".xls")
            '##########################################excel自动保存程序###########################
            Me.DataGridView1.Rows.Add()  'datagridview增加行
            objCa.Measure()                '测试
            DataGridView1.Rows(i).Cells(0).Value = i + 1
            DataGridView1.Rows(i).Cells(1).Value = objProbe.Lv
            DataGridView1.Rows(i).Cells(2).Value = objProbe.sx
            DataGridView1.Rows(i).Cells(3).Value = objProbe.sy
            DataGridView1.Rows(i).Cells(4).Value = objProbe.T
            DataGridView1.Rows(i).Cells(5).Value = objProbe.duv
            DataGridView1.Rows(i).Cells(6).Value = DateTime.Now.ToShortDateString()
            DataGridView1.Rows(i).Cells(7).Value = DateTime.Now.ToLongTimeString()

            Chart1.Series("初始值").Points.AddXY(current_time, 1)
            Chart1.Series("当前值").Points.AddXY(current_time, DataGridView1.Rows(i).Cells(1).Value / k)
            Chart1.Series("LT95").Points.AddXY(current_time, 0.95 * DataGridView1.Rows(a).Cells(1).Value / k)

            '##########################################excel自动保存程序###########################
            ex.Cells(i + 2, 1) = i + 1
            ex.Cells(i + 2, 2) = objProbe.Lv
            ex.Cells(i + 2, 3) = objProbe.sx
            ex.Cells(i + 2, 4) = objProbe.sy
            ex.Cells(i + 2, 5) = objProbe.T
            ex.Cells(i + 2, 6) = objProbe.duv
            ex.Cells(i + 2, 7) = DateTime.Now.ToShortDateString()
            ex.Cells(i + 2, 8) = DateTime.Now.ToLongTimeString()

            ex.DisplayAlerts = False    '关闭提示
            ex.ActiveWorkbook.SaveAs("D:\寿命测试\" & filename & ".xls")
            ex.Quit()
            ex = Nothing
            '保存
            '关闭
            '##########################################excel自动保存程序###########################

            t1 = timeGetTime
            While timeGetTime < t1 + Period  '延时，把控制权转让给其他操作
                Application.DoEvents()
                If isMsr = False Then               '停止测试
                    ButtonCancel.Enabled = False
                    ButtonMeasure.Enabled = True
                    Button2.Enabled = True
                    Exit Sub
                End If
            End While
            t1 = timeGetTime
            current_time = DateTime.Now.ToString("dd HH:mm")
            DataGridView1.FirstDisplayedScrollingRowIndex = DataGridView1.RowCount - 1  'datagridview显示为最后一行
        Next
        ButtonCancel.Enabled = False
        ButtonMeasure.Enabled = True
        ButtonCalZero.Enabled = True
        Button2.Enabled = True
        Exit Sub
er:
        DspError()
        End
    End Sub
    Public Sub ButtonCalZero_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonCalZero.Click
retry:
        ButtonMeasure.Enabled = False
        ButtonCalZero.Enabled = False
        Try
            objCa.CalZero()
        Catch er As Exception
            If MessageBox.Show("Zero Cal Error" + Chr(13) + "Retry?", "CalZero", MessageBoxButtons.OKCancel) = DialogResult.Cancel Then
                objCa.RemoteMode = 0
                End
            End If
            GoTo retry
        End Try
        ButtonMeasure.Enabled = True
        ButtonCalZero.Enabled = True
    End Sub
    Public Sub objCa_ExeCalZero() Handles objCa.ExeCalZero
        If MessageBox.Show("CalZero?", "CalZero", MessageBoxButtons.OKCancel) = DialogResult.Cancel Then
            Exit Sub
        End If
        ButtonMeasure.Enabled = False
        ButtonCalZero.Enabled = False
retry:
        Try
            objCa.CalZero()
        Catch er As Exception
            MessageBox.Show("Zero Cal Error!" + Chr(13))
            GoTo retry
        End Try
        ButtonMeasure.Enabled = True
        ButtonCalZero.Enabled = True
    End Sub
    Public Sub DspError()
        Dim msg As String
        msg = "Error from" + Err.Source + Chr(10) + Chr(13)
        msg = msg + Err.Description + Chr(10) + Chr(13)
        msg = msg + "HR:" + (Err.Number - vbObjectError).ToString
        MessageBox.Show(msg)
    End Sub
    Public Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        objCa.RemoteMode = 0
    End Sub
     Public filename As String
    Private Sub ExcelWrite()
        Dim xlApp As Excel.Application
        Dim xlBook As Excel.Workbook
        Dim xlSheet1 As Excel.Worksheet
        xlApp = CreateObject("Excel.Application")
        xlBook = xlApp.Workbooks.Add
        xlSheet1 = xlBook.Worksheets("sheet1")
        xlSheet1.Name = "aging001"
        xlApp.Visible = False

        '去除dataGridView1的编号列（这里也可以不要）
        Dim m As Integer
        For m = 0 To DataGridView1.ColumnCount - 1
            xlSheet1.Cells(1, m + 1) = Me.DataGridView1.Columns(m).HeaderText
        Next m

        '往excel表里添加数据
        Dim i As New Integer
        For i = 0 To DataGridView1.RowCount - 1
            Dim j As New Integer
            For j = 0 To DataGridView1.ColumnCount - 1
                xlSheet1.Cells(i + 2, j + 1) = DataGridView1(j, i).Value
            Next j
        Next i
        xlBook.SaveAs(filename)
        '保存
        '关闭
        xlApp.DisplayAlerts = False
        xlBook.Close()
        xlApp.Quit()
        xlApp = Nothing
        xlBook = Nothing
        xlSheet1 = Nothing
    End Sub
    Private Sub SaveFileName()
        Dim SaveFileDialog1 As New SaveFileDialog()
        SaveFileDialog1.DefaultExt = "*.xls"   '默认格式
        SaveFileDialog1.InitialDirectory = "D:\"  '默认路径
        SaveFileDialog1.Filter = "Excel files(*.xls)|*.xls|All files (*.*)|*.*" '可选格式
        SaveFileDialog1.Title = "保存数据"  '对话框标题
        SaveFileDialog1.FilterIndex = 1
        SaveFileDialog1.ShowDialog()
        filename = SaveFileDialog1.FileName
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Call SaveFileName()
        Call ExcelWrite()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        DataGridView1.Rows.Clear()
        Chart1.ChartAreas.Clear() '清除所有绘图区
        Dim newChartAreas1 As New ChartArea("Default") '新增绘图区
        Chart1.ChartAreas.Add(newChartAreas1)
        Chart1.ChartAreas("Default").BackColor = Color.FromName("GradientInactiveCaption") '设置绘图区颜色
        Chart1.ChartAreas("Default").BackGradientStyle = GradientStyle.HorizontalCenter '设置绘图区颜色渐变方式
        Chart1.ChartAreas("Default").AxisX.IsMarginVisible = True
        'Chart1.ChartAreas("Default").Area3DStyle.Enable3D = True '启用3D显示
        Chart1.ChartAreas("Default").AxisX.Title = "时间" 'X轴名称
        Chart1.ChartAreas("Default").AxisY.Title = "亮度百分比" 'Y轴名称
        Chart1.ChartAreas("Default").AxisY.Minimum = 0.94
        Chart1.ChartAreas("Default").AxisY.Maximum = 1.01
        Chart1.ChartAreas("Default").AxisY.Interval = 0.01

        Chart1.Titles.Clear()
        Dim newTitles1 As New Title("aging亮度衰减图") '建立标题
        newTitles1.Text = "aging亮度衰减图"
        Chart1.Titles.Add(newTitles1)

        Chart1.Series.Clear() '清除所有数据集
        Dim newSeries1 As New Series("初始值") '新增数据集
        newSeries1.ChartType = SeriesChartType.Line '直线
        newSeries1.BorderWidth = 1
        newSeries1.Color = Color.Blue
        newSeries1.XValueType = ChartValueType.Time
        newSeries1.IsValueShownAsLabel = False
        Chart1.Series.Add(newSeries1)

        Dim newSeries2 As New Series("当前值")
        newSeries2.ChartType = SeriesChartType.Line
        newSeries2.BorderWidth = 2
        newSeries2.Color = Color.Green
        newSeries2.XValueType = ChartValueType.Time
        newSeries2.IsValueShownAsLabel = False
        newSeries2.MarkerStyle = MarkerStyle.Square
        Chart1.Series.Add(newSeries2)

        Dim newSeries3 As New Series("LT95")
        newSeries3.ChartType = SeriesChartType.Line
        newSeries3.BorderWidth = 1
        newSeries3.Color = Color.OrangeRed
        newSeries3.XValueType = ChartValueType.Time
        newSeries3.IsValueShownAsLabel = False
        Chart1.Series.Add(newSeries3)
    End Sub
End Class